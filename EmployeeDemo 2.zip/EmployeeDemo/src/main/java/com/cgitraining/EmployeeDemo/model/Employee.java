package com.cgitraining.EmployeeDemo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Value;

@Entity
@Table(name="DemoEmp")
public class Employee {

	@Id
	@GeneratedValue
	@Column(name="employeeId")
	private long empId;
	
	@Column(name="empname")
	@Max(value=5)
	private String empName;
	
	@Column(name="salary")
	private String salary;
	

	public long getEmpId() {
		return empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
		
	}
	
	
                                                      
}
