package com.cgitraining.EmployeeDemo.exception;

import org.springframework.stereotype.Component;

@Component
public class ErrorDTO {
	
	private int errorCode;
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private String message;
	

}
