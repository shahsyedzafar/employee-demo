package com.cgitraining.EmployeeDemo.resource;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cgitraining.EmployeeDemo.exception.EmployeeNotFoundException;
import com.cgitraining.EmployeeDemo.model.Employee;
import com.cgitraining.EmployeeDemo.service.EmployeeService;

@RestController
@RequestMapping("/v1")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/hello")
	public String sayHello() {
		return "Hello Sprieeeng Boot";
	}
	
	@GetMapping("/employee/{empId}")
	public Employee findEmployee(@PathVariable("empId") long empId) {
		
		Employee employee = employeeService.findEmployee(empId);
		if(employee==null) {
			throw new EmployeeNotFoundException("Employee not found in db!!");
		}
		return employee;
	}
	
	@PostMapping("employee")
	public void createEmployee(@RequestBody @Valid Employee employee, BindingResult result) {
		
		employeeService.createEmployee(employee);
	}
}
