package com.cgitraining.EmployeeDemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgitraining.EmployeeDemo.dao.EmployeeRepository;
import com.cgitraining.EmployeeDemo.model.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository repo;
	
	public Employee findEmployee(long id) {
	
		return repo.findByEmpId(id);
	}
	
	public void createEmployee(Employee emp) {
		repo.save(emp);
	}
		
}
